def suma(num1, num2):
    print("Resultado: ", num1+num2)

def multiplica(num1, num2):
    print("Resultado: ", num1*num2)

def resta(num1, num2):
    print("Resultado: ", num1-num2)

def dividir(num1, num2):
    print("Resultado: ", num1/num2)

def potencia(num1, num2):
    print("Resultado: ", num1**num2)

def redondear(num1):
    print("Resultado: ", round(num1))