#contiene una descripcion del paquete a distribuir
from setuptools import setup
setup(  
    name="paqueteCalculos", 
    version="1.0.0",
    description="Paquete de calculos básicos",
    author="yo",
    author_email="guillermd@gmail.com",
    url="www.XXXX.es",
    packages=["Paquetes","Paquetes"], #si hubiera mas carpetas por medio, seria ["carpeta","carpeta.subcarpeta....fichero.py"]
)